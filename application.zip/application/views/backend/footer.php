</div>
</div>
</div>
<!-- Footer -->
<!--<hr>-->
<!--<footer class="main" align="right" style="background:none; border: none; text-align: right"><?php echo $footer; ?></footer>-->


<footer>
    <div class="pull-right">
        <?php echo $footer; ?>
    </div>
    <div class="clearfix"></div>
</footer>